﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace ScriptSurgee
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
            if (panel3.Controls.Count > 0)
                return;

            string scriptsFolderPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Scripts");

            panel3.Controls.Clear();

            if (!Directory.Exists(scriptsFolderPath))
            {
                return;
            }

            var files = Directory.GetFiles(scriptsFolderPath, "*.txt");

            int y = 10;

            foreach (var file in files)
            {
                var linkLabel = new LinkLabel
                {
                    Text = Path.GetFileNameWithoutExtension(file),
                    Location = new Point(10, y),
                    AutoSize = true,
                    LinkColor = Color.White,
                    ActiveLinkColor = Color.DarkOrchid
                };

                linkLabel.Click += (s, args) =>
                {
                    fastColoredTextBox1.Text = File.ReadAllText(file);
                };

                panel3.Controls.Add(linkLabel);

                y += linkLabel.Height + 5;
            }
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            RefreshPanel4();
        }

        private void RefreshPanel4()
        {
            panel3.Controls.Clear();

            string scriptsFolderPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Scripts");

            if (!Directory.Exists(scriptsFolderPath))
            {
                return;
            }

            var files = Directory.GetFiles(scriptsFolderPath, "*.txt");

            int y = 10;

            foreach (var file in files)
            {
                var linkLabel = new LinkLabel
                {
                    Text = Path.GetFileNameWithoutExtension(file),
                    Location = new Point(10, y),
                    AutoSize = true,
                    LinkColor = Color.White,
                    ActiveLinkColor = Color.DarkOrchid
                };

                linkLabel.Click += (s, args) =>
                {
                    fastColoredTextBox1.Text = File.ReadAllText(file);
                };

                panel3.Controls.Add(linkLabel);

                y += linkLabel.Height + 5;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Currently Broken!");
        }

        private void siticoneButton1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hello! Wonder How To Control Script Hub? Make a Folder called ' Scripts ' with the Caps S in documents tab on pc, then put a txt file name it the scripts name put the script in the txt file and save it and click the refresh button!");
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Clear();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            {
                // Create and configure the SaveFileDialog
                using (SaveFileDialog saveFileDialog = new SaveFileDialog())
                {
                    saveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
                    saveFileDialog.Title = "Save a Text File";

                    // Show the dialog and check if the user selected a file
                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        try
                        {
                            // Ensure the text to save is not null
                            string textToSave = fastColoredTextBox1.Text ?? string.Empty;

                            // Write the text to the selected file
                            System.IO.File.WriteAllText(saveFileDialog.FileName, textToSave);

                            // Optionally notify the user that the file was saved successfully
                            MessageBox.Show("File saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            // Handle any errors that may have occurred
                            MessageBox.Show($"An error occurred while saving the file: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}


